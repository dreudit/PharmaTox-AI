---
name: Serene Clinical Intelligence
colors:
  surface: '#f8fafa'
  surface-dim: '#d8dada'
  surface-bright: '#f8fafa'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f4'
  surface-container: '#eceeee'
  surface-container-high: '#e6e8e9'
  surface-container-highest: '#e1e3e3'
  on-surface: '#191c1d'
  on-surface-variant: '#44474c'
  inverse-surface: '#2e3131'
  inverse-on-surface: '#eff1f1'
  outline: '#75777c'
  outline-variant: '#c4c6cc'
  surface-tint: '#535f6f'
  primary: '#091523'
  on-primary: '#ffffff'
  primary-container: '#1e2a38'
  on-primary-container: '#8591a2'
  inverse-primary: '#bbc7da'
  secondary: '#40627e'
  on-secondary: '#ffffff'
  secondary-container: '#bbdeff'
  on-secondary-container: '#40627e'
  tertiary: '#081620'
  on-tertiary: '#ffffff'
  tertiary-container: '#1d2b35'
  on-tertiary-container: '#84929f'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d7e3f6'
  primary-fixed-dim: '#bbc7da'
  on-primary-fixed: '#101c2a'
  on-primary-fixed-variant: '#3c4857'
  secondary-fixed: '#cce6ff'
  secondary-fixed-dim: '#a8caea'
  on-secondary-fixed: '#001e31'
  on-secondary-fixed-variant: '#274a65'
  tertiary-fixed: '#d5e4f2'
  tertiary-fixed-dim: '#b9c8d6'
  on-tertiary-fixed: '#0f1d27'
  on-tertiary-fixed-variant: '#3a4854'
  background: '#f8fafa'
  on-background: '#191c1d'
  surface-variant: '#e1e3e3'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.03em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 38px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '500'
    lineHeight: 30px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '500'
    lineHeight: 26px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 17px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 23px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 19px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-md: 1.5rem
  gutter-lg: 2rem
  margin: 1.25rem
  margin-md: 2.5rem
  margin-lg: 4rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
  space-2xl: 4rem
---

## Brand & Style
The design system establishes a clinical, ultra-refined atmosphere inspired by calm introspection and diagnostic precision. Designed for proactive health monitoring and conversational medical intelligence, the interface removes cognitive burden, visual clutter, and clinical coldness.

The aesthetic fuses warm human minimalism with ethereal, translucent digital glass. Rather than boxing information into disjointed cards with heavy dividers, layout structures flow continuously over pure, breathable planes of off-white and pale mineral tones. Visual priority relies on generous whitespace, deliberate typographic scale, and quiet micro-surfaces. The emotional response is centered around tranquility, absolute safety, and frictionless cognitive clarity.

## Colors
The palette evokes sterile precision softened by ambient natural daylight. 

- **Primary (`#1E2A38` - Deep Slate):** Anchors headings, high-contrast actions, and essential iconography without the visual harshness of pure black.
- **Secondary (`#5A7C99` - Soft Slate Mist):** Provides muted structural contrast for secondary typography, inactive states, and subtle semantic status.
- **Tertiary (`#D7E6F4` - Glacial Blue Translucent):** Applied to active pill toggles, conversational user bubbles, interactive highlights, and soft indicator washes.
- **Neutral (`#F9FBFB` - Pure Mineral Chalk):** The foundational ambient background, supplemented by `#FFFFFF` for continuous surface elevations and `#ECEFEF` for hairline separators.

Functional tints include a soft sage (`#DCEEE6`) for positive health vitals and a muted rose quartz (`#FBE8E8`) for alerts, both subdued to avoid clinical alarm.

## Typography
Plus Jakarta Sans delivers geometric precision balanced by gentle curvature, preventing clinical copy from feeling detached or mechanized.

- **Headlines:** Set in medium to semi-bold weights with negative tracking to preserve structural authority and focus during consultations and summary reviews.
- **Body:** Generous line heights (`1.5` to `1.55`) paired with relaxed paragraph spacing allow long-form conversational responses, diagnostic explanations, and dosage protocols to breathe.
- **Labels & Microcopy:** Clean letter-spacing prevents visual crowding on dense data feeds, biometric metrics, and bottom navigational items.

## Layout & Spacing
The layout rejects dense grid constraints in favor of a fluid, respiratory canvas that prioritizes vertical calm:

- **Breakpoints:** Mobile (`< 768px`), Tablet (`768px - 1024px`), Desktop (`> 1024px`).
- **Mobile Foundation:** A single-column flow anchored by `margin: 1.25rem` outer margins. Content units are separated by generous vertical intervals (`space-xl`), allowing sections to self-demarcate without container walls.
- **Large Screens:** Max-width bounds capped at `720px` for conversational / health-journal views and `1140px` for multi-metric dashboard grids to maintain optimal reading line length.
- **Rhythm:** Spacing follows strict multiples of 8px (with 4px for precise micro-adjustments), giving content a deliberate, meditative cadence.

## Elevation & Depth
Depth is realized through optical density, diffusion, and luminous layers rather than hard structural drops.

- **Atmospheric Layering:** The canvas surface sits at `#F9FBFB`. Higher-priority planes utilize pure `#FFFFFF` enriched by a whisper of ambient shadow: `0 8px 32px -4px rgba(30, 42, 56, 0.03)`.
- **Frosted Translucency (Glassmorphism):** The floating navigation dock and persistent chat prompt bars employ `rgba(255, 255, 255, 0.72)` coupled with a multi-directional blur `backdrop-filter: blur(24px) saturate(180%)`.
- **Zero Heavy Borders:** Bounding strokes are entirely banned on standard containers. Where edge delineation is functionally required for high-density inputs, a single hairline tint of `rgba(30, 42, 56, 0.06)` is applied.

## Shapes
Forms are organic, welcoming, and pill-dominant to eliminate sharp visual tension.

- **Buttons & Control Surfaces:** Curvature defaults to full pill radii (`9999px`), ensuring tactile comfort on touch-first interactions.
- **Large Floating Canvases:** Surface containers, diagnostic sheets, and modal drawers utilize oversized smooth radii (`rounded-xl` at `3rem` / `48px` or `2rem` / `32px` on smaller displays), simulating smoothed river stone geometry.
- **Micro-Indicators:** Badges, chips, and notification dots preserve symmetrical spherical or rounded-capsule boundaries.

## Components

### Buttons
- **Primary:** Deep slate background (`#1E2A38`), pure white typography, full pill radius (`rounded-full`), padded with `0.875rem 1.75rem`. Zero shadow, translating into a soft `0.97` scale compress under active tap.
- **Secondary / Soft:** Translucent glacial tint (`rgba(215, 230, 244, 0.4)`), deep slate text, pill-shaped, providing quiet contrast for non-critical flow progressions.
- **Ghost:** Invisible surface, slate-tinted label, displaying a soft glacial bloom on hover or focus.

### Input Fields & Conversational Bar
- Floating conversational prompt dock anchored to the viewport bottom, enveloped in frosted glass (`rgba(255, 255, 255, 0.8)` with `blur(20px)`), floating 16px above the device safe area.
- Internal text field has no inner stroke; text sits cleanly on transparent fill with subtle `#5A7C99` placeholder text, accompanied by an effortless round voice/send action trigger.

### Floating Bottom Navigation
- Island pill dock suspended over content (`margin: 0 auto 1.5rem auto`), with an ultra-soft glass background (`rgba(255, 255, 255, 0.78)`), hairline border (`rgba(30, 42, 56, 0.04)`), and ambient floor shadow (`0 12px 36px rgba(0, 0, 0, 0.04)`).
- Icons use optical 20px strokes that subtly illuminate into `#1E2A38` with an underlying micro-dot indicator when active, maintaining minimal visual noise.

### Floating Surfaces & Cards
- Reject the typical card-and-box appearance. Data metrics, insights, and health markers render on continuous white plains that fade seamlessly into the off-white neutral canvas.
- When containerization is mandatory, use pure white `#FFFFFF` with no border, 24px internal padding, and generous `2rem` corner radius.

### Chips & Badges
- Fluid capsule badges finished in `rgba(215, 230, 244, 0.5)` background with `#1E2A38` text, sized at `label-sm` or `label-md`. 
- Filter chips toggle state smoothly via opacity transitions rather than high-contrast color shifts.

### Checkboxes & Radios
- Soft circular toggles with seamless fill transitions (`#D7E6F4` transitioning to `#1E2A38` when active) and smooth internal dot/check reveals, eliminating boxy geometric toggles.