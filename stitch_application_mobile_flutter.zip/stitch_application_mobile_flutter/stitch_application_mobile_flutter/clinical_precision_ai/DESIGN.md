---
name: Clinical Precision AI
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#45464d'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839b'
  inverse-primary: '#bec6e0'
  secondary: '#006a61'
  on-secondary: '#ffffff'
  secondary-container: '#86f2e4'
  on-secondary-container: '#006f66'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#410004'
  on-tertiary-container: '#ef4444'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#89f5e7'
  secondary-fixed-dim: '#6bd8cb'
  on-secondary-fixed: '#00201d'
  on-secondary-fixed-variant: '#005049'
  tertiary-fixed: '#ffdad7'
  tertiary-fixed-dim: '#ffb3ad'
  on-tertiary-fixed: '#410004'
  on-tertiary-fixed-variant: '#930013'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 16px
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 14px
  citation-badge:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 12px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-mobile: 0.75rem
  margin: 1.5rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1.25rem
  space-xl: 2rem
---

## Brand & Style

The design system establishes a high-acuity, authoritative, and calm clinical environment tailored for emergency physicians, toxicologists, hospital pharmacists, and critical care teams. When managing acute poisoning, drug-drug interactions, or overdose protocols, cognitive load must remain at absolute zero. 

The aesthetic is Modern Clinical Minimalist: an interplay of surgical cleanliness, disciplined layout structures, and high-density legibility inspired by modern frontier AI interfaces combined with the rigorous scannability of medical formularies. It rejects unnecessary skeuomorphism, loud synthetic gradients, and distracting animations in favor of crystalline typography, distinct risk tiering, and surgical border precision.

Visual priorities:
- **Instant Triage Legibility**: High typographic contrast and deterministic visual hierarchy ensure life-critical warnings are recognized in fractions of a second.
- **Academic & Scientific Trust**: Perplexity-grade inline citation badges, structured pharmacological tables, and transparent sourcing eliminate the feeling of an opaque "black box" model.
- **Ergonomic Calm**: Crisp off-white surfaces and deep slate foundations mitigate visual fatigue during stressful overnight shifts.

## Colors

The color palette reinforces clinical rigor, precision, and deterministic safety hierarchy:

- **Primary (`#0F172A` - Slate Obsidian)**: The structural backbone of the interface. Applied to major typographic levels, brand touchpoints, primary buttons, and navigational bars. It provides absolute grounding without the harshness of pure `#000000`.
- **Secondary (`#0D9488` - Clinical Teal)**: Evokes scientific accuracy, antidote clarity, and targeted therapeutics. Reserved for active conversational states, high-confidence AI reasoning markers, verified pharmacology pills, and active filter tabs.
- **Tertiary (`#EF4444` - Toxidrome Critical Red)**: Strict clinical contraindication and high-severity toxicity alert color. Used for life-threatening antidotes, lethal drug interactions, and emergency thresholds. A supporting warm warning tone (`#F59E0B` - Amber Caution) serves intermediate warnings, hepatic/renal adjustments, and monitoring flags.
- **Neutral (`#64748B` - Slate Silver)**: Calibrated for anatomical metadata, metric units, tertiary timestamps, dosage guidelines, and subtle grid dividers.
- **Surfaces (`#F8FAFC` to `#FFFFFF`)**: Sterile laboratory whites and subtle surgical off-whites prevent clinical glare while maximizing contrast for complex pharmacokinetic charts.

## Typography

Typography bridges rapid clinical comprehension and scientific validation:

- **Headlines (Plus Jakarta Sans)**: Contemporary, approachable yet rigorous geometry. Its open counters ensure immediate readability on hand-held mobile devices under intense ambient hospital lighting.
- **Body (Inter)**: The standard for high-legibility digital text. Exceptional x-height, clear differentiation of ambiguous glyphs (I, l, 1, 0, O), and optimized for continuous medical reading and detailed pharmacology monographs.
- **Labels, Metrics & Citations (JetBrains Mono)**: Monospaced precision for dosages (e.g., `mg/kg/h`, `µmol/L`), serum concentrations, PubMed IDs, half-life parameters, and Perplexity-style citation anchors.

Dynamic Type Rules:
- Body text maintains a relaxed 1.5–1.6x line-height ratio to prevent visual skipping across complex chemical nomenclature.
- In severe medical warning banners, label weights shift to `600` with strict all-caps tracking (`+0.05em`).

## Layout & Spacing

The layout is strictly mobile-first, designed for single-thumb emergency interaction and responsive chat flows. 

- **Grid Architecture**: 4-column fluid mobile grid shifting to an 8-column layout on clinical tablet workstations.
- **Rhythm**: Compact yet breathable 4px/8px incremental rhythm. Clinical dialogue feeds adopt an asymmetric stream: user queries are right-aligned, compact, and slate-grounded; AI responses are full-width, left-aligned, structured with dedicated sub-containers for pharmacology data, toxidromes, and source pills.
- **Safe Zone & Dynamic Island Constraints**: Critical actionable buttons (e.g., "Calculate Antidote Dosage", "Call Poison Control Center") are anchored in a sticky bottom control deck with 16px bottom padding accounting for device home indicators.

## Elevation & Depth

Visual hierarchy relies on crisp tonal layers and low-contrast ghost outlines rather than murky, diffuse drop shadows. This matches physical laboratory equipment displays and high-precision clinical monitors.

- **Layer 0 (Canvas Base)**: `#F8FAFC` - Soft, anti-glare clinical backdrop.
- **Layer 1 (Card & Module Surface)**: `#FFFFFF` with a 1px solid border (`#E2E8F0`). Zero shadow or subtle ambient blur `0 1px 3px rgba(15, 23, 42, 0.04)`.
- **Layer 2 (Floating Triage Bars, Modals, & Action Drawers)**: `#FFFFFF` backed by `0 8px 24px -4px rgba(15, 23, 42, 0.08)`, framed with a 1px `#CBD5E1` outline.
- **Layer 3 (Active Emergency Callouts)**: Solid tint washes (`#FEF2F2` for lethal contraindications, `#F0FDFA` for verified clinical guidance) encapsulated by a high-contrast 1.5px boundary.

## Shapes

The design uses a restrained, semi-soft shape scale (`roundedness: 1`). Medical interfaces require architectural firmness; overly rounded or pill-shaped cards feel casual, whereas completely sharp corners feel abrasive and dated.

- **Primary Cards & Containers**: 8px border radius (`0.5rem`).
- **Input Fields & Dosage Tables**: 6px border radius (`0.375rem`).
- **Citation Badges & Toxidrome Tags**: Compact 4px border radius (`0.25rem`) for a precise, micro-index feel.
- **Floating Action Buttons & Quick Pills**: Rounded capsules (9999px) strictly for interactive conversational prompts and filter chips to distinguish them from data tables.

## Components

### Buttons
- **Primary**: Solid `#0F172A` background, `#FFFFFF` typography, 8px radius, 44px minimum touch height for rapid interaction.
- **Clinical Action (Antidote / Confirm)**: Solid `#0D9488` background, `#FFFFFF` text. Subtle active scale feedback (`scale(0.98)`).
- **Destructive / Emergency**: Solid `#EF4444` background with white text, used strictly for life-safety overrides and poison center speed dials.
- **Secondary / Ghost**: `#FFFFFF` background, 1px border `#CBD5E1`, text `#0F172A`.

### Input Fields & Search / Prompt Bar
- Fixed bottom conversational input field with an integrated micro-action bar: voice input (dictation mode for gloved clinicians), image capture (pill identification / strip packaging scan), and direct toxicology protocol selector.
- 1px border `#CBD5E1`, transitioning to 1.5px `#0D9488` upon focus, with zero external glowing rings.

### Citation Badges & References (Perplexity Style)
- Formatted as inline super-badges: small rectangular tags with a soft teal or slate wash (`#F1F5F9`), containing a `#0F172A` monospaced index `[1]`, `[2]`.
- Tapping expands a bottom sheet or inline drawer revealing the PubMed ID, evidence level (e.g., Meta-Analysis, Case Report, Cochrane), publication year, and direct DOI link.

### Pharmacology Dosage Tables
- Dense, tabular data presentation with alternating subtle zebra striping (`#FFFFFF` / `#F8FAFC`).
- Monospaced numerals aligned right for dosage comparisons (`mg/kg`, `mL/h`). Headers set in `label-sm` uppercase with low-contrast borders.

### Warning & Toxidrome Alert Blocks
- **Severity Level 1 (Contraindication / Antidote Urgent)**: Background `#FEF2F2`, border 1.5px `#EF4444`, left accent stripe 4px wide. Header paired with an alert shield icon.
- **Severity Level 2 (Hepatic / Renal Alert)**: Background `#FFFBEB`, border 1.5px `#F59E0B`, left accent stripe 4px wide.
- **Severity Level 3 (Clinical Pearl / Pharmacokinetics)**: Background `#F0FDFA`, border 1.5px `#0D9488`, teal accent stripe.

### Quick Prompts & Pharmacological Chips
- Horizontally scrollable capsule chips located above the input bar (e.g., "Nomogramme Paracétamol", "Antidote Digoxine", "Clairance Cockcroft-Gault").
- Border 1px `#E2E8F0`, background `#FFFFFF`, text `#334155`.